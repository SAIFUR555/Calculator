﻿using System;
using System.Windows.Forms;

namespace calculatorassignment
{
    public partial class Form1 : Form
    {
        double num1;
        double num2;
        double result = 0;
        string operation = "";
        bool operatorSelected = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        }

        // Number button clicks
        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text += "1";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text += "2";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            textBox1.Text += "3";
        }

        private void button4_Click(object sender, EventArgs e)
        {
            textBox1.Text += "4";
        }

        private void button5_Click(object sender, EventArgs e)
        {
            textBox1.Text += "5";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text += "6";
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text += "7";
        }

        private void button8_Click(object sender, EventArgs e)
        {
            textBox1.Text += "8";
        }

        private void button9_Click(object sender, EventArgs e)
        {
            textBox1.Text += "9";
        }

        private void button0_Click(object sender, EventArgs e)
        {
            textBox1.Text += "0";
        }

        // Clear button
        private void buttonClear_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            result = 0;
            num1 = 0;
            num2 = 0;
            operation = "";
            operatorSelected = false;
        }

        // Set operator method
        private void SetOperator(string newOperation)
        {
            if (!operatorSelected)
            {
                num1 = Convert.ToDouble(textBox1.Text);
                operatorSelected = true;
            }

            operation = newOperation;
            textBox1.Clear();
        }

        // Operation button clicks
        private void buttonAdd_Click(object sender, EventArgs e)
        {
            SetOperator("+");
        }

        private void buttonSubtract_Click(object sender, EventArgs e)
        {
            SetOperator("-");
        }

        private void buttonMultiply_Click(object sender, EventArgs e)
        {
            SetOperator("x");
        }

        private void buttonDivide_Click(object sender, EventArgs e)
        {
            SetOperator("/");
        }

        // Equal button to calculate the result
        private void buttonEqual_Click(object sender, EventArgs e)
        {
            num2 = Convert.ToDouble(textBox1.Text);

            switch (operation)
            {
                case "+":
                    result = num1 + num2;
                    break;
                case "-":
                    result = num1 - num2;
                    break;
                case "x":
                    result = num1 * num2;
                    break;
                case "/":
                    if (num2 != 0)
                    {
                        result = num1 / num2;
                    }
                    else
                    {
                        MessageBox.Show("Invalid");
                        return;
                    }
                    break;
                default:
                    MessageBox.Show("Unknown operator");
                    return;
            }

            textBox1.Text = result.ToString();
            operatorSelected = false;
        }

        
    }
}
